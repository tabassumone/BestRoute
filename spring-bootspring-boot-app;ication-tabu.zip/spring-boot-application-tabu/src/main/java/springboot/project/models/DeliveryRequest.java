package springboot.project.models;

import java.util.List;

public class DeliveryRequest {

	private List<DeliveryExecutive> deliveryExecutives;
	private List<GeoLocation> restaurants;

	public DeliveryRequest() {
		super();
	}

	public DeliveryRequest(List<DeliveryExecutive> deliveryExecutives, List<GeoLocation> restaurants) {
		this.deliveryExecutives = deliveryExecutives;
		this.restaurants = restaurants;
	}

	public List<DeliveryExecutive> getDeliveryExecutives() {
		return deliveryExecutives;
	}

	public List<GeoLocation> getRestaurants() {
		return restaurants;
	}

	public void setDeliveryExecutives(List<DeliveryExecutive> deliveryExecutives) {
		this.deliveryExecutives = deliveryExecutives;
	}

	public void setRestaurants(List<GeoLocation> restaurants) {
		this.restaurants = restaurants;
	}

	@Override
	public String toString() {
		return "DeliveryRequest [deliveryExecutives=" + deliveryExecutives + ", restaurants=" + restaurants + "]";
	}

}
