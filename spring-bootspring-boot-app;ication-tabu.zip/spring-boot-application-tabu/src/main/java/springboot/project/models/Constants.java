package springboot.project.models;

public class Constants {
	public static final double AVERAGE_SPEED_KM_PER_HOUR = 20.0;
	public static final double EARTH_RADIUS_KM = 6371.0;
}
