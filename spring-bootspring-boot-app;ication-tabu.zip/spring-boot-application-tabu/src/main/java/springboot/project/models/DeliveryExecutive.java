package springboot.project.models;

import java.util.List;

public class DeliveryExecutive {

	private GeoLocation location;
	private List<GeoLocation> orders;

	public DeliveryExecutive() {
		super();
	}

	public DeliveryExecutive(GeoLocation location, List<GeoLocation> orders) {
		this.location = location;
		this.orders = orders;
	}

	public GeoLocation getLocation() {
		return location;
	}

	public void setLocation(GeoLocation location) {
		this.location = location;
	}

	public List<GeoLocation> getOrders() {
		return orders;
	}

	public void setOrders(List<GeoLocation> orders) {
		this.orders = orders;
	}

	@Override
	public String toString() {
		return "DeliveryExecutive [location=" + location + ", orders=" + orders + "]";
	}

}
