package springboot.project.services;

import org.springframework.stereotype.Component;

import springboot.project.models.Constants;
import springboot.project.models.GeoLocation;

@Component
public class DistanceCalculator {

    public double calculateDistance(GeoLocation loc1, GeoLocation loc2) {
        double lat1 = Math.toRadians(loc1.getLatitude());
        double lon1 = Math.toRadians(loc1.getLongitude());
        double lat2 = Math.toRadians(loc2.getLatitude());
        double lon2 = Math.toRadians(loc2.getLongitude());

        double dlon = lon2 - lon1;
        double dlat = lat2 - lat1;

        double a = Math.pow(Math.sin(dlat / 2), 2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(dlon / 2), 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        double distance = Constants.EARTH_RADIUS_KM * c; // Earth radius in kilometers
        return distance;
    }
}

