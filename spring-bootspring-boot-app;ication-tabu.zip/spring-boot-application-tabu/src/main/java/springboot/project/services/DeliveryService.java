package springboot.project.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import springboot.project.models.DeliveryExecutive;
import springboot.project.models.DeliveryRequest;
import springboot.project.models.GeoLocation;

@Service
public class DeliveryService {

	@Autowired
	private final DistanceCalculator distanceCalculator;

	public DeliveryService(DistanceCalculator distanceCalculator) {
		this.distanceCalculator = distanceCalculator;
	}

	final static int INF = 99999;

	// Method to optimize delivery for a given request
	public Map<String, List<String>> optimizeDelivery(DeliveryRequest deliveryRequest) {
		List<DeliveryExecutive> executiveLocations = deliveryRequest.getDeliveryExecutives();

		// Merge all locations
		Map<String, Integer> locationPositions = new HashMap<String, Integer>();
		int index = 0;
		for (DeliveryExecutive exec : executiveLocations) {
			String execName = exec.getLocation().getName();
			locationPositions.put(execName, index++);
			for (GeoLocation order : exec.getOrders()) {
				String orderName = order.getName();
				if (!locationPositions.containsKey(orderName)) {
					locationPositions.put(orderName, index++);
				}
			}
		}

		// Create distance matrix
		int n = locationPositions.size();
		double[][] distances = new double[n][n];
		for (int i = 0; i < n; i++) {
			Arrays.fill(distances[i], DeliveryService.INF);
			distances[i][i] = 0; // Distance to self is 0
		}

		// Populate distances based on executive and order locations
		for (DeliveryExecutive exec : executiveLocations) {
			String execName = exec.getLocation().getName();
			for (GeoLocation order : exec.getOrders()) {
				int execIndex = locationPositions.get(execName);
				int orderIndex = locationPositions.get(order.getName());
				distances[execIndex][orderIndex] = distances[orderIndex][execIndex] = distanceCalculator
						.calculateDistance(exec.getLocation(), order); // Assuming symmetric distances
			}
		}

		// Find shortest paths
		Map<String, Map<String, Double>> shortestPaths = DeliveryService.findShortestPaths(locationPositions,
				distances);

		// Convert shortest paths to optimized delivery format
		Map<String, List<String>> optimizedDelivery = new HashMap<String, List<String>>();
		for (DeliveryExecutive exec : executiveLocations) {
			String execName = exec.getLocation().getName();
			List<String> shortestPathLocations = new ArrayList<String>();
			Map<String, Double> pathLengths = shortestPaths.get(execName);
			for (Map.Entry<String, Double> pathEntry : pathLengths.entrySet()) {
				String destination = pathEntry.getKey();
				shortestPathLocations.add(destination);
			}
			optimizedDelivery.put(execName, shortestPathLocations);
		}

		return optimizedDelivery;
	}

	// Method to find shortest paths using Floyd Warshall algorithm
	public static Map<String, Map<String, Double>> findShortestPaths(Map<String, Integer> locationPositions,
			double[][] distances) {
		double[][] shortestDistances = floydWarshall(distances);
		return transformOutput(shortestDistances, locationPositions);
	}

	// Floyd Warshall algorithm
	private static double[][] floydWarshall(double[][] dist) {
		int n = dist.length;
		double[][] shortestDistances = new double[n][n];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				shortestDistances[i][j] = dist[i][j];
			}
		}
		for (int k = 0; k < n; k++) {
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					if (shortestDistances[i][k] + shortestDistances[k][j] < shortestDistances[i][j]) {
						shortestDistances[i][j] = shortestDistances[i][k] + shortestDistances[k][j];
					}
				}
			}
		}
		return shortestDistances;
	}

	// Transform output to match API requirements
	private static Map<String, Map<String, Double>> transformOutput(double[][] shortestDistances,
			Map<String, Integer> locationPositions) {
		Map<String, Map<String, Double>> paths = new HashMap<String, Map<String, Double>>();
		for (Map.Entry<String, Integer> entry1 : locationPositions.entrySet()) {
			String from = entry1.getKey();
			Map<String, Double> pathLengths = new HashMap<String, Double>();
			for (Map.Entry<String, Integer> entry2 : locationPositions.entrySet()) {
				String to = entry2.getKey();
				pathLengths.put(to, shortestDistances[entry1.getValue()][entry2.getValue()]);
			}
			paths.put(from, pathLengths);
		}
		return paths;
	}

}