package springboot.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestApi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(SpringRestApi.class, args);

	}

}
